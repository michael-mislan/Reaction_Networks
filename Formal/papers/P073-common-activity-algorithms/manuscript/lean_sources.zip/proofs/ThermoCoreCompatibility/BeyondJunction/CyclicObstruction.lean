import proofs.ThermoCoreCompatibility.MultiInterface.PathResponse

namespace ThermoCoreCompatibility.BeyondJunction.CyclicObstruction
noncomputable section
open MultiInterface
def w1 : Factors := ⟨1/5,1,by norm_num,by norm_num⟩
def w2 : Factors := ⟨1/25,1,by norm_num,by norm_num⟩
def w3 : Factors := ⟨1/100,1,by norm_num,by norm_num⟩
def w4 : Factors := ⟨8,1,by norm_num,by norm_num⟩
def w5 : Factors := ⟨1/2,1,by norm_num,by norm_num⟩
def pathA : Path := (Path.single w1).snoc w2
def pathB : Path := ((Path.single w3).snoc w4).snoc w5
def InBox (x : ℝ) : Prop := 1/1000000000 ≤ x ∧ x ≤ 999/1000
def State (s a t b c : ℝ) : Prop :=
  InBox s ∧ InBox a ∧ InBox t ∧ InBox b ∧ InBox c ∧
  w1.Productive s a ∧ w2.Productive a t ∧ w3.Productive s b ∧
  w4.Productive b c ∧ w5.Productive c t
def Feasible (s : ℝ) : Prop := ∃ a t b c, State s a t b c

theorem no_middle : ¬ Feasible (7/100) := by
  rintro ⟨a,t,b,c,_,_,_,_,_,h1,h2,h3,h4,h5⟩
  have hA : pathA.Realizes (7/100) t := ⟨a,h1,h2⟩
  have hB : pathB.Realizes (7/100) t := ⟨c,⟨b,h3,h4⟩,h5⟩
  have ha := (pathA.necessary (by norm_num) hA).2
  have hb := (pathB.necessary (by norm_num) hB).1
  have hcross : pathA.upper (7/100) < pathB.lower (7/100) := by
    norm_num [pathA,pathB,Path.upper,Path.lower,Factors.upper,Factors.lower,w1,w2,w3,w4,w5]
  exact (not_lt_of_ge (le_of_lt hcross)) (hb.trans ha)

theorem feasible_low : Feasible (1/500) := by
  refine ⟨(1/4096),(17780294759375622481/3319973926435546875000000),(3/131072),(5/262144),?_⟩
  norm_num [State,InBox,Factors.Productive,w1,w2,w3,w4,w5]

theorem feasible_high : Feasible (143/500) := by
  refine ⟨(237/2048),(27186602805116330414817/1574306328125000000000000),(85/1024),(139/2048),?_⟩
  norm_num [State,InBox,Factors.Productive,w1,w2,w3,w4,w5]

theorem noninterval_source_domain :
    Feasible (1/500) ∧ ¬ Feasible (7/100) ∧ Feasible (143/500) ∧
      (1/500 : ℝ) < 7/100 ∧ (7/100 : ℝ) < 143/500 := by
  exact ⟨feasible_low,no_middle,feasible_high,by norm_num,by norm_num⟩
end
end ThermoCoreCompatibility.BeyondJunction.CyclicObstruction
