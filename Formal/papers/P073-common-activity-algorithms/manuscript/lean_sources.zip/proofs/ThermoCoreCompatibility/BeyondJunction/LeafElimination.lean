import proofs.ThermoCoreCompatibility.BeyondJunction.IntervalProjection
import proofs.ThermoCoreCompatibility.BeyondJunction.SourceBoxes

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface

/-- Q contains every remaining constraint, sharing one parent coordinate.
The eliminated leaf occurs nowhere in Q. This scope condition is explicit. -/
theorem eliminate_target_leaf {V : Type*} (parent : V)
    (Q : (V → ℝ) → Prop) (w : Factors) (S : Set ℝ)
    {L U : ℝ} (hLU : L < U) (hin : Set.Ioo L U ⊆ S)
    (hout : S ⊆ Set.Icc L U)
    (hparent : ∀ z, Q z → 0 < z parent ∧ z parent < 1) :
    (∃ z, Q z ∧ ∃ y ∈ S, w.Productive (z parent) y) ↔
      ∃ z, Q z ∧ w.lower (z parent) < U ∧ L < w.upper (z parent) := by
  constructor
  · rintro ⟨z,hz,hy⟩
    exact ⟨z,hz,(target_interval_projection w S hLU hin hout
      (hparent z hz).1 (hparent z hz).2).mp hy⟩
  · rintro ⟨z,hz,hb⟩
    exact ⟨z,hz,(target_interval_projection w S hLU hin hout
      (hparent z hz).1 (hparent z hz).2).mpr hb⟩

theorem eliminate_source_leaf {V : Type*} (parent : V)
    (Q : (V → ℝ) → Prop) (w : Factors) (S : Set ℝ)
    {L U : ℝ} (hLU : L < U) (hL : 0 < L) (hU : U ≤ 1)
    (hin : Set.Ioo L U ⊆ S) (hout : S ⊆ Set.Icc L U) :
    (∃ z, Q z ∧ ∃ x ∈ S, w.Productive x (z parent)) ↔
      ∃ z, Q z ∧ w.lower L < z parent ∧ z parent < w.upper U := by
  constructor
  · rintro ⟨z,hz,hx⟩
    exact ⟨z,hz,(source_interval_projection w S hLU hL hU hin hout).mp hx⟩
  · rintro ⟨z,hz,hb⟩
    exact ⟨z,hz,(source_interval_projection w S hLU hL hU hin hout).mpr hb⟩

end ThermoCoreCompatibility.BeyondJunction
