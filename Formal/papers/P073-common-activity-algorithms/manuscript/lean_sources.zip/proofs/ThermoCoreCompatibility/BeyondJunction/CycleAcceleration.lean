import proofs.ThermoCoreCompatibility.BeyondJunction.TangentCounterexample

namespace ThermoCoreCompatibility.BeyondJunction
open MultiInterface

theorem strict_band_has_smaller (w : Factors) {x y : ℝ}
    (hp : w.Productive x y) :
    ∃ Y, Y < y ∧ w.Productive x Y := by
  obtain ⟨hl,hu⟩ := (w.productive_iff _ _).mp hp
  refine ⟨(w.lower x+y)/2,by linarith,(w.productive_iff _ _).mpr ?_⟩
  constructor <;> linarith

def MarginState (x y : ℝ) : Prop :=
  1/10 ≤ x ∧ x ≤ 1/2 ∧ 1/100 ≤ y ∧ y ≤ 1/2 ∧
    unitFactors.lower x+1/100 ≤ y ∧ y+1/100 ≤ unitFactors.upper x

theorem cycle_root_is_least {r : ℝ}
    (hr0 : (1/10:ℝ) ≤ r) (hr1 : r ≤ 1/2)
    (heq : r*(1-r) = 3/25) :
    MarginState r (unitFactors.lower r+1/100) ∧
    ∀ x y, MarginState x y → r ≤ x ∧ unitFactors.lower r+1/100 ≤ y := by
  have hgap : unitFactors.lower r+1/50 = unitFactors.upper r := by
    norm_num [unitFactors,Factors.lower,Factors.upper]
    nlinarith
  constructor
  · refine ⟨hr0,hr1,?_,?_,le_rfl,?_⟩
    · have := unitFactors.lower_pos (show 0 < r by linarith)
      linarith
    · have hs : r^2 ≤ 1/4 := by nlinarith [sq_nonneg (r-1/2)]
      norm_num [unitFactors,Factors.lower]
      nlinarith
    · linarith
  · intro x y hh
    obtain ⟨hx0,hx1,_,_,hl,hu⟩ := hh
    have hxr : r ≤ x := by
      by_contra hn
      have hlt : x < r := lt_of_not_ge hn
      have hprod := mul_pos (sub_pos.mpr hlt) (show 0 < 1-r-x by linarith)
      norm_num [unitFactors,Factors.lower,Factors.upper] at hl hu
      nlinarith
    have hm := unitFactors.lower_strictMono.monotoneOn (show 0 ≤ r by linarith)
      (show 0 ≤ x by linarith) hxr
    exact ⟨hxr,by linarith⟩

end ThermoCoreCompatibility.BeyondJunction
