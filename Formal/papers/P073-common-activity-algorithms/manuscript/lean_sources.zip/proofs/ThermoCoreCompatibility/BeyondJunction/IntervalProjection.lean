import proofs.ThermoCoreCompatibility.MultiInterface.PathResponse

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface

/-- Eliminating a target interval: strict edges erase endpoint flags on a
nonsingleton child interval. Both flags still matter when testing emptiness. -/
theorem target_interval_projection (w : Factors) (S : Set ℝ)
    {L U x : ℝ} (hLU : L < U) (hin : Set.Ioo L U ⊆ S)
    (hout : S ⊆ Set.Icc L U) (hx : 0 < x) (hx1 : x < 1) :
    (∃ y ∈ S, w.Productive x y) ↔ w.lower x < U ∧ L < w.upper x := by
  constructor
  · rintro ⟨y,hy,hp⟩
    obtain ⟨hl,hu⟩ := (w.productive_iff _ _).mp hp
    exact ⟨lt_of_lt_of_le hl (hout hy).2, lt_of_le_of_lt (hout hy).1 hu⟩
  · rintro ⟨hG,hF⟩
    have hg := w.lower_lt_upper hx hx1
    have hb : max L (w.lower x) < min U (w.upper x) :=
      lt_min (max_lt hLU hG) (max_lt hF hg)
    obtain ⟨y,hyL,hyU⟩ := exists_between hb
    refine ⟨y,hin ⟨lt_of_le_of_lt (le_max_left _ _) hyL,
      lt_of_lt_of_le hyU (min_le_left _ _)⟩, (w.productive_iff _ _).mpr ?_⟩
    exact ⟨lt_of_le_of_lt (le_max_right _ _) hyL,
      lt_of_lt_of_le hyU (min_le_right _ _)⟩

/-- Eliminating a source interval uses a simultaneous blend in the activity
and the edge response. It includes a limiting upper endpoint equal to one. -/
theorem source_interval_projection (w : Factors) (S : Set ℝ)
    {L U y : ℝ} (hLU : L < U) (hL : 0 < L) (hU : U ≤ 1)
    (hin : Set.Ioo L U ⊆ S) (hout : S ⊆ Set.Icc L U) :
    (∃ x ∈ S, w.Productive x y) ↔ w.lower L < y ∧ y < w.upper U := by
  constructor
  · rintro ⟨x,hx,hp⟩
    have hb := hout hx
    obtain ⟨hl,hu⟩ := (w.productive_iff _ _).mp hp
    exact ⟨lt_of_le_of_lt (w.lower_strictMono.monotoneOn hL.le
      (le_trans hL.le hb.1) hb.1) hl,
      lt_of_lt_of_le hu (w.upper_strictMono.monotoneOn
        (le_trans hL.le hb.1) (le_trans hL.le hLU.le) hb.2)⟩
  · intro hh
    let X : ℝ → ℝ := fun t => (1-t)*L+t*U
    let Y : ℝ → ℝ := fun t => (1-t)*w.lower (X t)+t*w.upper (X t)
    have hX : Continuous X := by dsimp [X]; fun_prop
    have hY : Continuous Y :=
      ((continuous_const.sub continuous_id).mul (w.continuous_lower.comp hX)).add
        (continuous_id.mul (w.continuous_upper.comp hX))
    have hy : y ∈ Set.Ioo (Y 0) (Y 1) := by simpa [Y,X] using hh
    obtain ⟨t,ht,he⟩ := intermediate_value_Ioo (show (0:ℝ) ≤ 1 by norm_num)
      hY.continuousOn hy
    have hXL : L < X t := by
      have := mul_pos ht.1 (sub_pos.mpr hLU)
      dsimp [X]; nlinarith
    have hXU : X t < U := by
      have := mul_pos (sub_pos.mpr ht.2) (sub_pos.mpr hLU)
      dsimp [X]; nlinarith
    refine ⟨X t,hin ⟨hXL,hXU⟩,?_⟩
    rw [← he]
    exact Path.blend_inside w ht.1 ht.2 (hL.trans hXL) (hXU.trans_le hU)

theorem singleton_target_projection (w : Factors) (x L : ℝ) :
    (∃ y ∈ ({L} : Set ℝ), w.Productive x y) ↔
      w.lower x < L ∧ L < w.upper x := by
  simp [w.productive_iff]

theorem singleton_source_projection (w : Factors) (y L : ℝ) :
    (∃ x ∈ ({L} : Set ℝ), w.Productive x y) ↔
      w.lower L < y ∧ y < w.upper L := by
  simp [w.productive_iff]

end ThermoCoreCompatibility.BeyondJunction
