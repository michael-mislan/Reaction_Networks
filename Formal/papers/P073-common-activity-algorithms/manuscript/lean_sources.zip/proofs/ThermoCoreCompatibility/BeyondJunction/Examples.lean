import proofs.ThermoCoreCompatibility.BeyondJunction.TangentCounterexample

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface

theorem height_two_positive :
    unitFactors.Productive (4/5) (7/10) ∧
    unitFactors.Productive (7/10) (23/40) := by
  norm_num [Factors.Productive,unitFactors]

theorem height_two_boundary_negative :
    ¬ unitFactors.Productive (7/10) (14/25) := by
  norm_num [Factors.Productive,unitFactors]

theorem height_two_margin :
    (1/150:ℝ) ≤ 7/10-unitFactors.lower (4/5) ∧
    (1/150:ℝ) ≤ unitFactors.upper (4/5)-7/10 ∧
    (1/150:ℝ) ≤ 23/40-unitFactors.lower (7/10) ∧
    (1/150:ℝ) ≤ unitFactors.upper (7/10)-23/40 := by
  norm_num [Factors.lower,Factors.upper,unitFactors]

end ThermoCoreCompatibility.BeyondJunction
