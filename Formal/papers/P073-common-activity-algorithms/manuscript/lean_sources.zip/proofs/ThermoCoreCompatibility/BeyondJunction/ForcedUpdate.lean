import proofs.ThermoCoreCompatibility.BeyondJunction.OrderClosure

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface

theorem lower_update_dominated (w : Factors) (D : Set ℝ)
    {x zx zy r : ℝ} (hx : 0 ≤ x) (hxx : x ≤ zx)
    (hz : w.Productive zx zy) (hzy : zy ∈ D)
    (least : ∀ t ∈ D, w.lower x < t → r ≤ t) : r ≤ zy := by
  apply least zy hzy
  exact lt_of_le_of_lt
    (w.lower_strictMono.monotoneOn hx (le_trans hx hxx) hxx)
    ((w.productive_iff _ _).mp hz).1

theorem upper_update_dominated (w : Factors) (D : Set ℝ)
    {y zx zy r : ℝ} (hyy : y ≤ zy)
    (hz : w.Productive zx zy) (hzx : zx ∈ D)
    (least : ∀ t ∈ D, y < w.upper t → r ≤ t) : r ≤ zx := by
  exact least zx hzx (lt_of_le_of_lt hyy ((w.productive_iff _ _).mp hz).2)

theorem lower_exhaustion (w : Factors) (D : Set ℝ)
    {x zx zy : ℝ} (hx : 0 ≤ x) (hxx : x ≤ zx)
    (hz : w.Productive zx zy) (hzy : zy ∈ D)
    (empty : ∀ t ∈ D, t ≤ w.lower x) : False := by
  have hh := lt_of_le_of_lt
    (w.lower_strictMono.monotoneOn hx (le_trans hx hxx) hxx)
    ((w.productive_iff _ _).mp hz).1
  exact (not_lt_of_ge (empty zy hzy)) hh

theorem upper_exhaustion (w : Factors) (D : Set ℝ)
    {y zx zy : ℝ} (hyy : y ≤ zy)
    (hz : w.Productive zx zy) (hzx : zx ∈ D)
    (empty : ∀ t ∈ D, w.upper t ≤ y) : False := by
  have hh := lt_of_le_of_lt hyy ((w.productive_iff _ _).mp hz).2
  exact (not_lt_of_ge (empty zx hzx)) hh

end ThermoCoreCompatibility.BeyondJunction
