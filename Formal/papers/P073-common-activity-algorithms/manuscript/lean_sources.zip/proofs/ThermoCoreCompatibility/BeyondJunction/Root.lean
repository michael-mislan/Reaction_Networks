import proofs.ThermoCoreCompatibility.BeyondJunction.LeafElimination
import proofs.ThermoCoreCompatibility.BeyondJunction.ForcedUpdate
import proofs.ThermoCoreCompatibility.BeyondJunction.MarginTransfer
import proofs.ThermoCoreCompatibility.BeyondJunction.DesignableDAG
import proofs.ThermoCoreCompatibility.BeyondJunction.Examples

/-! Exact boxed forest elimination: formal mathematical boundary.

The imported leaf equivalences are the new core operations; SourceBoxes docks
literal per-core currents to one shared activity vector. The full bottom-up
forest algorithm, its induction, exact algebraic representation, and bit bound
are proved conventionally in notes/FOREST_THEOREM.md. This file does not claim
a Lean-verified implementation of algebraic root isolation or the Python pilot.
The unrestricted fixed-factor cyclic-undirected-graph problem remains open.
-/

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface Hypergraph

theorem terminal_source_reduction {V E : Type*}
    [DecidableEq V] [DecidableEq E] [Fintype V]
    (A : PairAssembly V E) (w : E → Factors) (lo hi : V → ℝ) :
    (∃ z, (∀ v, lo v ≤ z v ∧ z v ≤ hi v) ∧
      ∀ e, (WeightedSource.motif A w e).Productive
        ((WeightedSource.network A w).current z)) ↔
      ∃ z, BoxedProductive A.src A.dst w lo hi z := by
  exact exists_congr (fun z => boxed_source_iff A w lo hi z)

end ThermoCoreCompatibility.BeyondJunction
