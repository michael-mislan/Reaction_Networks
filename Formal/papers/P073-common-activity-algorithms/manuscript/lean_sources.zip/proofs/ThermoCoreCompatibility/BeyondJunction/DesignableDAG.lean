import proofs.ThermoCoreCompatibility.BeyondJunction.SourceBoxes
import Mathlib.Tactic.FieldSimp

namespace ThermoCoreCompatibility.BeyondJunction

open MultiInterface Hypergraph

noncomputable def rankActivity (h r : ℕ) : ℝ :=
  4/5-((r:ℝ)+1)/(20*((h:ℝ)+2))

theorem rank_activity_bounds (h r : ℕ) (hr : r ≤ h) :
    (3/4:ℝ) < rankActivity h r ∧ rankActivity h r < 4/5 := by
  have hh : 0 ≤ (h:ℝ) := Nat.cast_nonneg h
  have hrr : 0 ≤ (r:ℝ) := Nat.cast_nonneg r
  have hrh : (r:ℝ) ≤ h := Nat.cast_le.mpr hr
  have hd : 0 < 20*((h:ℝ)+2) := by positivity
  have hp : 0 < ((r:ℝ)+1)/(20*((h:ℝ)+2)) := div_pos (by linarith) hd
  have hu : ((r:ℝ)+1)/(20*((h:ℝ)+2)) < 1/20 := by
    apply (div_lt_iff₀ hd).mpr
    linarith
  unfold rankActivity
  constructor <;> linarith

theorem rank_activity_decreases (h r s : ℕ) (hrs : r < s) :
    rankActivity h s < rankActivity h r := by
  have hd : 0 < 20*((h:ℝ)+2) := by positivity
  have hrs' : (r:ℝ) < s := Nat.cast_lt.mpr hrs
  have := (div_lt_div_iff_of_pos_right hd).mpr (show (r:ℝ)+1 < (s:ℝ)+1 by linarith)
  unfold rankActivity
  linarith

theorem design_pair {x y : ℝ} (hy : (3/4:ℝ) < y) (hyx : y < x)
    (hx : x < 4/5) :
    ∃ w : Factors, w.b = 1 ∧ w.Productive x y ∧
      (11/200:ℝ) < 2*(w.b*(y-x^2))-w.a*(x-y) ∧
      (11/200:ℝ) < w.a*(x-y)-w.b*(y-x^2) := by
  have hs : x^2 < (4/5:ℝ)^2 := (sq_lt_sq₀ (by linarith) (by norm_num)).mpr hx
  have hq : (11/100:ℝ) < y-x^2 := by nlinarith
  let a : ℝ := 3*(y-x^2)/(2*(x-y))
  have ha : 0 < a := div_pos (by nlinarith) (by linarith)
  have hp : a*(x-y) = 3*(y-x^2)/2 := by
    dsimp [a]
    field_simp [ne_of_gt (sub_pos.mpr hyx)]
  refine ⟨⟨a,1,ha,by norm_num⟩,rfl,?_,?_,?_⟩
  · change 0 < 2*(1*(y-x^2))-a*(x-y) ∧ 0 < a*(x-y)-1*(y-x^2)
    rw [hp]
    constructor <;> nlinarith
  · change (11/200:ℝ) < 2*(1*(y-x^2))-a*(x-y)
    rw [hp]; nlinarith
  · change (11/200:ℝ) < a*(x-y)-1*(y-x^2)
    rw [hp]; nlinarith

theorem ranked_source_design {V E : Type*} [DecidableEq V] [DecidableEq E] [Fintype V]
    (A : PairAssembly V E) (h : ℕ) (r : V → ℕ)
    (hr : ∀ v, r v ≤ h) (he : ∀ e, r (A.src e) < r (A.dst e)) :
    ∃ (w : E → Factors) (z : V → ℝ),
      (∀ v, (3/4:ℝ) < z v ∧ z v < 4/5) ∧
      (∀ e, (w e).b = 1) ∧
      (∀ e, (WeightedSource.motif A w e).Productive
        ((WeightedSource.network A w).current z)) ∧
      ∀ e, (11/200:ℝ) < 2*((w e).b*(z (A.dst e)-z (A.src e)^2))-
          (w e).a*(z (A.src e)-z (A.dst e)) ∧
        (11/200:ℝ) < (w e).a*(z (A.src e)-z (A.dst e))-
          (w e).b*(z (A.dst e)-z (A.src e)^2) := by
  classical
  let z : V → ℝ := fun v => rankActivity h (r v)
  have hb : ∀ v, (3/4:ℝ) < z v ∧ z v < 4/5 := fun v => rank_activity_bounds h (r v) (hr v)
  have hp : ∀ e, ∃ w : Factors, w.b = 1 ∧ w.Productive (z (A.src e)) (z (A.dst e)) ∧
      (11/200:ℝ) < 2*(w.b*(z (A.dst e)-z (A.src e)^2))-w.a*(z (A.src e)-z (A.dst e)) ∧
      (11/200:ℝ) < w.a*(z (A.src e)-z (A.dst e))-w.b*(z (A.dst e)-z (A.src e)^2) := by
    intro e
    exact design_pair (hb _).1 (rank_activity_decreases h _ _ (he e)) (hb _).2
  choose w hw using hp
  refine ⟨w,z,hb,fun e => (hw e).1,?_,fun e => (hw e).2.2⟩
  intro e
  exact (WeightedSource.current_productive_iff A w e z).mpr (hw e).2.1

end ThermoCoreCompatibility.BeyondJunction
